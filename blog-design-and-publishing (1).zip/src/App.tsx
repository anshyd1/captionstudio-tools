import { useEffect, useState, useRef } from "react";

export default function App() {
  const [copiedCaption, setCopiedCaption] = useState<string | null>(null);
  const [activeCategory, setActiveCategory] = useState("attitude");
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [tocOpen, setTocOpen] = useState(false);
  const heroRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    document.title = "Viral Instagram Captions 2026: 100+ Hinglish Captions + Growth Strategy | CaptionStudio";
    
    // Add meta description for SEO
    let metaDesc = document.querySelector('meta[name="description"]');
    if (!metaDesc) {
      metaDesc = document.createElement('meta');
      metaDesc.setAttribute('name', 'description');
      document.head.appendChild(metaDesc);
    }
    metaDesc.setAttribute('content', '100+ viral Instagram captions 2026 in Hinglish. Attitude, Love, Sad, Motivation captions for reels. Free AI caption generator, growth strategy, SEO tips for creators.');
    
    // Add structured data
    const script = document.createElement('script');
    script.type = 'application/ld+json';
    script.text = JSON.stringify({
      "@context": "https://schema.org",
      "@type": "BlogPosting",
      "headline": "Viral Instagram Captions 2026: 100+ Hinglish Captions",
      "description": "100+ viral Instagram captions in Hinglish for 2026 with growth strategy",
      "author": { "@type": "Organization", "name": "CaptionStudio" },
      "publisher": { "@type": "Organization", "name": "CaptionStudio", "logo": { "@type": "ImageObject", "url": "https://captionstudio.in/logo.png" }},
      "datePublished": "2026-01-15",
      "image": "https://images.unsplash.com/photo-1611162616475-46b635cb6868?w=1200"
    });
    document.head.appendChild(script);
    
    return () => {
      document.head.removeChild(script);
    };
  }, []);

  const copyCaption = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedCaption(text);
    setTimeout(() => setCopiedCaption(null), 2000);
  };

  const captionCategories = {
    attitude: [
      "Vibe alag hai, copy mat karna 🔥",
      "Main hero hu apni story ka, side role nahi chahiye",
      "Attitude nahi, standard high hai 💯",
      "Log badle, main nahi",
      "Kismat likhne wala upar hai, neeche wale bas jalte hain",
      "Mood off? Sorry, main always on 🔛",
      "Tumhare liye option tha, mere liye main hi kaafi hu",
      "Chup rehta hu matlab darr nahi, bas ignore karta hu",
      "Royalty khoon me hai, dikhawa nahi karta",
      "Main wahi hu jise tum samajh nahi paaye",
      "Success meri, jealousy tumhari 😎",
      "Level up kar raha hu, tum same hi raho",
      "Fake logon se door, real vibe ke paas",
      "Baat kam, kaam zyada",
      "Meri life, mere rules - simple",
      "Play safe? Bhai main game change karta hu",
      "Haters kaam pe lage, main naam pe",
      "Socha tha rok loge? Sorry, main unstoppable hu",
      "Crown heavy hai par main carry kar leta hu 👑",
      "Zero se start kiya, hero banke dikhaunga",
      "Tum soch rahe ho, main kar raha hu",
      "Meri kahaani, meri zubaani",
      "Duniya bole kuch bhi, main sunta khud ki",
      "Limit? Bhai main woh word manta hi nahi",
      "Chhote log, chhoti soch - not my scene",
    ],
    love: [
      "Tum mile toh lagta hai sab mil gaya ❤️",
      "Ishq wala love, filmy wala forever",
      "Tu mere dil ka WiFi, bina tere no connection",
      "Pyaar me pagal hona bhi royalty hai",
      "Tere bina adhura, tere saath pura",
      "Dil ki baat lips tak aayi, tu sun le zara",
      "Love at first sight? Nahi bhai, har sight pe love",
      "Tu hai toh sab hai, simple si baat",
      "Meri duniya, tu aur teri muskaan",
      "Ishq hai ya addiction? Pata nahi, bas tu chahiye",
      "Hath pakad le, zindagi saath chalenge",
      "Teri aankhon me mera ghar hai",
      "Pyaar me jeet har koi chahta, main bas tujhe chahta",
      "Tu mera favorite notification hai 📱❤️",
      "Dil ne kaha tu, dimaag ne bhi haan kaha",
      "Ek tu, ek main, aur puri kaynat",
      "Love story likhni hai, pen tu la, paper main",
      "Tere bina coffee bhi feeki lagti hai",
      "Mera pyaar, no returns, no exchange",
      "Tu pass ho toh time slow, tu door toh fast forward",
      "Dil ka charger tu hai, low battery pe hu main",
      "Pyaar me pagal, aur proud hu ispe",
      "Tumhare liye toh main pura zamana chhod du",
      "Ishq ka dose daily chahiye, dr. ne bola hai",
      "Teri smile = meri peace",
    ],
    sad: [
      "Hasna seekha hai, dard chhupana bhi",
      "Dil toota nahi, bas samajh gaya",
      "Kuch rishte words se nahi, silence se khatam hote hain",
      "Main theek hu - sabse bada jhoot",
      "Raatein lambi, baatein kam",
      "Muskurahat ke peeche kahani hai",
      "Chhod diya sab, ab khud ko pakda hai",
      "Log aate hain, sikha ke jaate hain",
      "Dil bhari hai, zubaan khaali",
      "Tanhaayi bhi ab dost lagne lagi",
      "Sab kuch tha, bas tu nahi",
      "Yaadein rehti hain, log nahi",
      "Main badla nahi, bas samajh gaya",
      "Dard me bhi ek sukoon hai",
      "Kahaani adhuri, par main pura hu",
      "Chup hu matlab toota nahi, soch raha hu",
      "Dil se nikle the, dimaag me reh gaye",
      "Log poochte hain theek ho? Main hasta hu",
      "Kuch zakhm dikhte nahi, mehsoos hote hain",
      "Akele chalna seekh liya",
      "Bheed me bhi akela hu",
      "Tuta dil, par strong vibe",
      "Raat ko sochta hu, din ko hasta hu",
      "Move on? Process me hu",
      "Dil ka mausam aaj cloudy hai ☁️",
    ],
    motivation: [
      "Kal se nahi, abhi se start 🚀",
      "Dream bada hai, neend chhoti",
      "Mehnat silent, success loud",
      "Rukna nahi, jhukna nahi",
      "1% better har din = 365% saal me",
      "Comfort zone se bahar, growth zone me",
      "Fail hua? Good, seekh raha hu",
      "Main apna competition, koi aur nahi",
      "Consistency > motivation",
      "Small steps, big results",
      "Discipline = freedom",
      "Aaj ka kaam kal pe mat daal",
      "Excuses ya results - choose one",
      "Grind now, shine later",
      "Manzil door hai par rasta saaf hai",
      "No pain, no gain - purani baat, sachchi baat",
      "Tu rukega? Main nahi",
      "Focus on progress, not perfection",
      "Har din naya chance hai",
      "Winners never quit",
      "Apne sapno ke liye lad",
      "Time waste mat kar, invest kar",
      "Aaj ka hustle, kal ka muscle",
      "Believe karo, achieve karo",
      "Main karunga, main hi karunga",
    ],
  };

  const tableOfContents = [
    { id: "why-captions", title: "Why Captions Matter 2026" },
    { id: "algorithm", title: "Instagram Algorithm" },
    { id: "captions", title: "100+ Viral Captions" },
    { id: "formula", title: "Viral Formula" },
    { id: "mistakes", title: "Common Mistakes" },
    { id: "ai-tool", title: "AI Tool (2 Sec)" },
  ];

  return (
    <div className="min-h-screen bg-white text-zinc-900 antialiased">
      {/* Fonts */}
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Fraunces:opsz,wght@9..144,700;9..144,800&display=swap');
        * { font-family: 'Inter', system-ui, -apple-system, sans-serif; }
        h1, h2, h3, .display { font-family: 'Fraunces', Georgia, serif; }
      `}</style>

      {/* Top Bar */}
      <div className="bg-zinc-950 text-white text-[12px]">
        <div className="mx-auto max-w-[1180px] px-4 h-8 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span className="hidden sm:inline opacity-70">Trending:</span>
            <a href="#captions" className="hover:underline">100+ Viral Captions</a>
            <span className="opacity-30">•</span>
            <a href="../tools/caption-generator.html" className="hover:underline">AI Generator</a>
          </div>
          <div className="flex items-center gap-3">
            <span className="hidden sm:inline opacity-70">Join 12K+ creators</span>
            <a href="https://t.me/skill2incomehub" className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-[#229ED9] hover:bg-[#1e8bc3] transition font-medium">
              <svg width="12" height="12" viewBox="0 0 24 24" fill="white"><path d="M12 0C5.373 0 0 5.373 0 12s5.373 12 12 12 12-5.373 12-12S18.627 0 12 0zm5.894 8.221l-1.97 9.28c-.145.658-.537.818-1.084.508l-3-2.21-1.446 1.394c-.14.18-.357.295-.6.295l.213-3.054 5.56-5.022c.24-.213-.054-.334-.373-.121l-6.87 4.326-2.96-.924c-.64-.203-.658-.64.135-.954l11.57-4.458c.538-.196 1.006.128.832.941z"/></svg>
              Telegram
            </a>
          </div>
        </div>
      </div>

      {/* Header */}
      <header className="sticky top-0 z-40 bg-white/80 backdrop-blur-xl border-b border-zinc-200">
        <div className="mx-auto max-w-[1180px] px-4 h-[64px] flex items-center justify-between">
          <div className="flex items-center gap-6">
            <button 
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 -ml-2 hover:bg-zinc-100 rounded-lg transition"
              aria-label="Toggle menu"
            >
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M4 6h16M4 12h16M4 18h16"/>
              </svg>
            </button>
            
            <a href="/" className="flex items-center gap-2.5">
              <div className="h-9 w-9 rounded-2xl bg-zinc-900 grid place-items-center shadow-sm">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" className="text-white">
                  <path d="M4 8V6a2 2 0 0 1 2-2h2M4 16v2a2 2 0 0 0 2 2h2M16 4h2a2 2 0 0 1 2 2v2M16 20h2a2 2 0 0 0 2-2v-2" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
                  <circle cx="12" cy="12" r="3" stroke="currentColor" strokeWidth="2"/>
                </svg>
              </div>
              <div>
                <div className="font-bold text-[17px] leading-none tracking-tight">CaptionStudio</div>
                <div className="text-[10px] text-zinc-500 -mt-0.5 font-medium">.in</div>
              </div>
            </a>

            <nav className="hidden lg:flex items-center gap-1">
              {[
                { name: "Tools", href: "../tools/caption-generator.html" },
                { name: "Blog", href: "../blog/" },
                { name: "Guide", href: "../guide.html" },
                { name: "Earn", href: "../earning.html" },
              ].map((item) => (
                <a key={item.name} href={item.href} className="px-3 py-1.5 text-[14px] font-medium text-zinc-600 hover:text-zinc-900 hover:bg-zinc-50 rounded-lg transition">
                  {item.name}
                </a>
              ))}
            </nav>
          </div>

          <div className="flex items-center gap-2">
            <a href="../tools/caption-generator.html" className="hidden sm:inline-flex h-9 px-4 items-center gap-1.5 rounded-xl bg-zinc-900 text-white text-[13px] font-semibold hover:bg-zinc-800 transition shadow-sm">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                <path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"/>
              </svg>
              AI Generator
            </a>
          </div>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="lg:hidden border-t border-zinc-200 bg-white">
            <div className="px-4 py-3 space-y-1">
              {[
                { name: "AI Caption Generator", href: "../tools/caption-generator.html", desc: "Generate viral captions" },
                { name: "Instagram Growth Guide", href: "../guide.html", desc: "Complete strategy" },
                { name: "Earn Money Online", href: "../earning.html", desc: "Monetize content" },
                { name: "All Blog Posts", href: "../blog/", desc: "500+ captions" },
              ].map((item) => (
                <a key={item.name} href={item.href} className="block px-3 py-2.5 rounded-xl hover:bg-zinc-50 transition">
                  <div className="font-medium text-[14px]">{item.name}</div>
                  <div className="text-[12px] text-zinc-500">{item.desc}</div>
                </a>
              ))}
            </div>
          </div>
        )}
      </header>

      {/* Hero Section with Image */}
      <section ref={heroRef} className="border-b border-zinc-200">
        <div className="mx-auto max-w-[1180px] px-4 py-10 lg:py-14">
          <div className="grid lg:grid-cols-[1.1fr_0.9fr] gap-10 items-start">
            <div>
              <div className="inline-flex items-center gap-2 px-2.5 py-1 rounded-full bg-amber-50 border border-amber-200 text-[11px] font-semibold text-amber-700 mb-4">
                <span className="h-1.5 w-1.5 rounded-full bg-amber-500 animate-pulse" />
                UPDATED JAN 2026 • ALGORITHM CHANGES
              </div>
              
              <h1 className="display text-[40px] sm:text-[52px] lg:text-[60px] font-extrabold leading-[0.95] tracking-[-0.02em] mb-4">
                Viral Instagram Captions 2026
                <span className="block text-zinc-400">100+ Hinglish + Growth Strategy</span>
              </h1>
              
              <p className="text-[17px] leading-relaxed text-zinc-600 max-w-[600px] mb-6">
                Reels pe reach nahi aa rahi? Caption galat hai. 2026 me Instagram search engine ban gaya hai. 
                Ye 100+ ready-made Hinglish captions copy karo, viral ho jao. Plus: algorithm kaise kaam karta hai.
              </p>

              <div className="flex flex-wrap items-center gap-3 mb-8">
                <div className="flex items-center gap-2 text-[13px]">
                  <img 
                    src="https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=40&h=40&fit=crop&crop=face" 
                    alt="Rahul Sharma - Instagram growth expert" 
                    width="24" 
                    height="24" 
                    loading="lazy"
                    className="h-6 w-6 rounded-full object-cover"
                  />
                  <span className="text-zinc-700">By <strong>Rahul Sharma</strong></span>
                </div>
                <span className="text-zinc-300">•</span>
                <span className="text-[13px] text-zinc-500">8 min read</span>
                <span className="text-zinc-300">•</span>
                <span className="text-[13px] text-zinc-500">Updated 15 Jan 2026</span>
              </div>

              <div className="flex flex-wrap gap-2.5">
                <a href="#captions" className="inline-flex items-center gap-1.5 px-4 h-10 rounded-xl bg-zinc-900 text-white text-[14px] font-semibold hover:bg-zinc-800 transition shadow-sm">
                  Get 100+ Captions
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                    <path d="M19 14v4a2 2 0 01-2 2H7a2 2 0 01-2-2v-4M12 3v11m0 0l4-4m-4 4l-4-4"/>
                  </svg>
                </a>
                <a href="../tools/caption-generator.html" className="inline-flex items-center gap-1.5 px-4 h-10 rounded-xl border border-zinc-300 text-[14px] font-medium hover:bg-zinc-50 transition">
                  Try AI Tool Free
                </a>
              </div>
            </div>

            <div className="relative">
              <div className="aspect-[4/3] rounded-[28px] overflow-hidden bg-zinc-100 border border-zinc-200 shadow-xl shadow-zinc-900/5">
                <img
                  src="https://images.unsplash.com/photo-1611162616475-46b635cb6868?w=800&h=600&fit=crop"
                  alt="Viral Instagram captions 2026 for reels and posts - Hinglish captions example on phone screen"
                  width="800"
                  height="600"
                  loading="eager"
                  fetchPriority="high"
                  className="h-full w-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/10 to-transparent" />
                <div className="absolute bottom-0 left-0 right-0 p-6 text-white">
                  <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-white/20 backdrop-blur-md text-[11px] font-semibold mb-2">
                    LIVE EXAMPLE
                  </div>
                  <p className="text-[15px] font-medium leading-snug">
                    "Maine 7 din me 0 se 5k reach le aaya bas caption badal ke"
                  </p>
                  <p className="text-[12px] text-white/70 mt-1">47,329 views • 2.4K saves</p>
                </div>
              </div>
              
              {/* Floating stats */}
              <div className="absolute -bottom-4 -left-4 hidden sm:block">
                <div className="px-3 py-2 rounded-2xl bg-white shadow-xl border border-zinc-200">
                  <div className="text-[11px] text-zinc-500">Avg. reach increase</div>
                  <div className="text-[20px] font-bold text-emerald-600 leading-none">+340%</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <main className="mx-auto max-w-[1180px] px-4 py-10 lg:py-12">
        <div className="grid grid-cols-1 xl:grid-cols-[1fr_320px] gap-12 items-start">
          <article className="min-w-0 max-w-[780px]">
            {/* Table of Contents - Mobile */}
            <div className="xl:hidden mb-8">
              <button 
                onClick={() => setTocOpen(!tocOpen)}
                className="w-full flex items-center justify-between p-3 rounded-xl border border-zinc-200 bg-zinc-50 text-[14px] font-medium"
              >
                <span className="flex items-center gap-2">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <path d="M4 6h16M4 12h16M4 18h7"/>
                  </svg>
                  Table of Contents
                </span>
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className={`transition-transform ${tocOpen ? 'rotate-180' : ''}`}>
                  <path d="M6 9l6 6 6-6"/>
                </svg>
              </button>
              {tocOpen && (
                <div className="mt-2 p-3 rounded-xl border border-zinc-200 bg-white">
                  <nav className="space-y-1">
                    {tableOfContents.map((item) => (
                      <a key={item.id} href={`#${item.id}`} className="block px-2 py-1.5 text-[13px] text-zinc-600 hover:text-zinc-900 hover:bg-zinc-50 rounded-lg">
                        {item.title}
                      </a>
                    ))}
                  </nav>
                </div>
              )}
            </div>

            {/* Intro */}
            <div className="prose prose-zinc max-w-none">
              <div className="not-prose mb-8 p-5 rounded-2xl bg-amber-50 border border-amber-200">
                <div className="flex gap-3">
                  <div className="shrink-0">
                    <div className="h-9 w-9 rounded-xl bg-amber-500 grid place-items-center text-white font-bold">!</div>
                  </div>
                  <div>
                    <h3 className="text-[15px] font-bold text-amber-900 mb-1">Sach bolo, ye tumhari problem hai na?</h3>
                    <p className="text-[14px] leading-relaxed text-amber-900/80 m-0">
                      Reel banate ho, 2 ghante edit karte ho… caption me likhte ho "Good vibes only ✨". Result? 47 views. 
                      <strong> Reach nahi aa rahi kyunki caption hi galat hai.</strong> 2026 me Instagram search engine hai, caption = SEO.
                    </p>
                  </div>
                </div>
              </div>

              <p className="lead text-[17px] leading-[1.75] text-zinc-700">
                2026 me Instagram ab sirf photo app nahi — <strong>ye ek full search engine ban gaya hai.</strong> Log Google pe nahi, Instagram pe search karte hain: "best cafe in Delhi", "workout motivation", "Hinglish captions".
              </p>
            </div>

            {/* Main Image */}
            <figure className="my-10">
              <div className="relative aspect-[16/9] rounded-2xl overflow-hidden bg-zinc-100 border border-zinc-200">
                <img
                  src="https://images.unsplash.com/photo-1611162618071-b39a2ec055fb?w=1200&h=675&fit=crop"
                  alt="Instagram algorithm 2026 showing how captions affect reach and search rankings"
                  width="1200"
                  height="675"
                  loading="lazy"
                  className="h-full w-full object-cover"
                />
              </div>
              <figcaption className="mt-2 text-[12px] text-zinc-500 text-center">
                Instagram 2026: Captions now drive 60% of search discovery. Source: Internal data from 10K+ posts.
              </figcaption>
            </figure>

            {/* Why Captions Matter */}
            <section id="why-captions" className="scroll-mt-24">
              <h2 className="display text-[28px] sm:text-[32px] font-extrabold tracking-tight mb-4">
                Why Captions Matter in 2026 (SEO + Algorithm)
              </h2>
              
              <div className="space-y-4 text-[16px] leading-[1.75] text-zinc-700">
                <p>
                  Bhai, 2026 ka algorithm samjho. Instagram ab <strong>3 cheez</strong> dekhta hai caption me:
                </p>

                <div className="not-prose grid sm:grid-cols-3 gap-3 my-6">
                  {[
                    { icon: "⏱️", title: "Watch Time", desc: "Log caption padhne ruke? Algorithm samjha - valuable hai", metric: "+127%" },
                    { icon: "💾", title: "Saves", desc: "Caption itna accha ki save kar liya? Reach 3x", metric: "+340%" },
                    { icon: "↗️", title: "Shares", desc: "DM me forward hua? Viral material samjha", metric: "+210%" },
                  ].map((item) => (
                    <div key={item.title} className="p-4 rounded-2xl border border-zinc-200 bg-white">
                      <div className="flex items-start justify-between mb-2">
                        <span className="text-[22px]">{item.icon}</span>
                        <span className="text-[11px] font-bold px-1.5 py-0.5 rounded-md bg-emerald-50 text-emerald-700 border border-emerald-200">{item.metric}</span>
                      </div>
                      <div className="font-semibold text-[14px] mb-1">{item.title}</div>
                      <div className="text-[12px] text-zinc-600 leading-snug">{item.desc}</div>
                    </div>
                  ))}
                </div>

                <p>
                  Main jab <em>"Good morning 🌞"</em> likhta tha, reach 200 thi. Jab maine <em>"Subah 5 baje uthke ye 3 kaam karo, life badal jayegi (save karke rakhna)"</em> likha, reach <strong>47,000</strong> hui. Same video, sirf caption badla.
                </p>

                <div className="not-prose my-6 p-4 rounded-2xl bg-violet-50 border border-violet-200">
                  <div className="flex items-center justify-between gap-4">
                    <div>
                      <div className="font-semibold text-[14px] text-violet-900">Try AI Caption Generator →</div>
                      <div className="text-[12px] text-violet-700/80 mt-0.5">2 second me viral caption, Hinglish me</div>
                    </div>
                    <a href="../tools/caption-generator.html" className="shrink-0 px-3.5 py-2 rounded-xl bg-violet-600 text-white text-[13px] font-semibold hover:bg-violet-700 transition shadow-sm">
                      Free Tool
                    </a>
                  </div>
                </div>
              </div>
            </section>

            {/* Algorithm */}
            <section id="algorithm" className="scroll-mt-24 mt-12">
              <h2 className="display text-[28px] sm:text-[32px] font-extrabold tracking-tight mb-4">
                Instagram Algorithm 2026: Simple breakdown
              </h2>

              <div className="relative aspect-[16/9] rounded-2xl overflow-hidden bg-zinc-100 border border-zinc-200 mb-6">
                <img
                  src="https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=1200&h=675&fit=crop"
                  alt="Instagram growth strategy showing search, hashtags, and caption optimization"
                  width="1200"
                  height="675"
                  loading="lazy"
                  className="h-full w-full object-cover"
                />
                <div className="absolute bottom-3 left-3 right-3">
                  <div className="px-3 py-2 rounded-xl bg-black/70 backdrop-blur-md text-white text-[12px]">
                    2026 Update: Search traffic now exceeds Explore by 34%
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                {[
                  {
                    n: "1",
                    title: "Search-first Instagram",
                    desc: "Log 'viral captions for reels 2026', 'Hinglish attitude captions' search karte hain. Ye keywords caption me honge = free traffic.",
                  },
                  {
                    n: "2",
                    title: "First 125 characters = gold",
                    desc: "Instagram sirf pehle 2 lines dikhata hai. Usme hook nahi = no 'more' click = no reach.",
                  },
                  {
                    n: "3",
                    title: "Dwell time matters",
                    desc: "3 sec vs 30 sec ruke? Instagram track karta hai. Lambi, interesting caption = algorithm khush.",
                  },
                ].map((item) => (
                  <div key={item.n} className="flex gap-3 p-4 rounded-2xl border border-zinc-200">
                    <div className="h-7 w-7 rounded-xl bg-zinc-900 text-white grid place-items-center text-[13px] font-bold shrink-0 mt-0.5">{item.n}</div>
                    <div>
                      <div className="font-semibold mb-1">{item.title}</div>
                      <div className="text-[14px] text-zinc-600 leading-relaxed">{item.desc}</div>
                    </div>
                  </div>
                ))}
              </div>

              <div className="mt-6 p-4 rounded-xl bg-zinc-50 border border-zinc-200">
                <p className="text-[14px] text-zinc-700 m-0">
                  <strong>Pro tip:</strong> <a href="../guide.html" className="text-violet-600 hover:underline font-medium">Instagram growth tips</a> me maine pura algorithm decode kiya hai. 7 minute padh lo, life set.
                </p>
              </div>
            </section>

            {/* Captions Section */}
            <section id="captions" className="scroll-mt-24 mt-14">
              <div className="flex items-end justify-between gap-4 mb-6">
                <div>
                  <h2 className="display text-[28px] sm:text-[36px] font-extrabold tracking-tight">
                    100+ Viral Captions (Copy-Paste Ready)
                  </h2>
                  <p className="text-[14px] text-zinc-600 mt-1">Har category me 25 captions. Tap to copy.</p>
                </div>
                <div className="hidden sm:flex items-center gap-1.5 text-[12px] text-zinc-500">
                  <span className="h-1.5 w-1.5 rounded-full bg-emerald-500"></span>
                  Updated weekly
                </div>
              </div>

              {/* Category Tabs */}
              <div className="not-prose flex gap-1.5 p-1 rounded-2xl bg-zinc-100 border border-zinc-200 w-fit mb-5">
                {Object.keys(captionCategories).map((cat) => (
                  <button
                    key={cat}
                    onClick={() => setActiveCategory(cat)}
                    className={`px-3.5 py-1.5 rounded-xl text-[13px] font-medium capitalize transition ${
                      activeCategory === cat
                        ? "bg-white shadow-sm border border-zinc-200 text-zinc-900"
                        : "text-zinc-600 hover:text-zinc-900"
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>

              {/* Captions Grid */}
              <div className="not-prose grid sm:grid-cols-2 gap-2.5">
                {captionCategories[activeCategory as keyof typeof captionCategories].map((caption, idx) => (
                  <div key={idx} className="group relative p-3.5 rounded-2xl border border-zinc-200 bg-white hover:border-zinc-300 hover:shadow-sm transition-all">
                    <div className="flex items-start gap-2.5">
                      <span className="text-[11px] font-mono text-zinc-400 mt-0.5 w-5 shrink-0">{idx + 1}</span>
                      <p className="flex-1 text-[14px] leading-snug text-zinc-800 pr-2">{caption}</p>
                      <button
                        onClick={() => copyCaption(caption)}
                        className="shrink-0 h-7 px-2.5 rounded-lg border border-zinc-200 bg-zinc-50 text-[11px] font-medium text-zinc-600 hover:bg-zinc-900 hover:text-white hover:border-zinc-900 transition-all"
                      >
                        {copiedCaption === caption ? "✓ Copied" : "Copy"}
                      </button>
                    </div>
                  </div>
                ))}
              </div>

              {/* Growth Tip */}
              <div className="not-prose mt-6 p-4 rounded-2xl bg-blue-50 border border-blue-200">
                <div className="flex gap-2.5">
                  <span className="text-[18px] leading-none">💡</span>
                  <div>
                    <div className="font-semibold text-[13px] text-blue-900 mb-1">Growth Tip for {activeCategory}</div>
                    <p className="text-[13px] leading-relaxed text-blue-900/80 m-0">
                      {activeCategory === "attitude" && "3-5 relevant hashtags: #attitude #hindiquotes #viral. 30 mat bharo, spam lagta hai. Post time: 7-9 PM."}
                      {activeCategory === "love" && "Partner ko first comment me tag karo. Engagement 2x. Best time: 8-10 PM (couples active)."}
                      {activeCategory === "sad" && "Last line me CTA: 'Comment karo agar relate kiya' - comments = reach. Post at 11 PM - 1 AM."}
                      {activeCategory === "motivation" && "Subah 6-8 AM post karo. Save rate sabse zyada. Add 'Save for later' in caption."}
                    </p>
                  </div>
                </div>
              </div>
            </section>

            {/* Formula */}
            <section id="formula" className="scroll-mt-24 mt-14">
              <h2 className="display text-[28px] sm:text-[32px] font-extrabold tracking-tight mb-4">
                Viral Caption Formula (3-Step)
              </h2>

              <div className="space-y-4">
                {[
                  { step: "HOOK", color: "bg-rose-500", desc: "Pehle 5 words me scroll roko", ex: ["Maine 30 din me 10k...", "Ye galti mat karna...", "Nobody tells you..."] },
                  { step: "VALUE", color: "bg-violet-500", desc: "Story do, but pura mat batao", ex: ["3 cheeze jo maine...", "Reason #2 will shock", "Save karke rakhna"] },
                  { step: "CTA", color: "bg-cyan-500", desc: "Batao kya karna hai", ex: ["Comment 'YES'", "Save this", "Share with friend"] },
                ].map((item) => (
                  <div key={item.step} className="relative pl-11">
                    <div className={`absolute left-0 top-0 h-8 w-8 rounded-xl ${item.color} grid place-items-center shadow-sm`}>
                      <span className="text-[11px] font-bold text-white">{item.step[0]}</span>
                    </div>
                    <div className="p-4 rounded-2xl border border-zinc-200 bg-zinc-50/50">
                      <div className="flex items-baseline gap-2 mb-1.5">
                        <h4 className="font-bold text-[14px]">{item.step}</h4>
                        <span className="text-[12px] text-zinc-500">— {item.desc}</span>
                      </div>
                      <div className="flex flex-wrap gap-1.5">
                        {item.ex.map((e, i) => (
                          <span key={i} className="px-2 py-1 rounded-lg bg-white border border-zinc-200 text-[11px] text-zinc-700">"{e}"</span>
                        ))}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </section>

            {/* Mistakes */}
            <section id="mistakes" className="scroll-mt-24 mt-14">
              <h2 className="display text-[26px] sm:text-[30px] font-extrabold tracking-tight mb-4">
                4 Mistakes Jo Reach Maar Dete Hain
              </h2>

              <div className="grid sm:grid-cols-2 gap-3">
                {[
                  { bad: "No hook", good: "Question ya bold claim se start", icon: "🎣" },
                  { bad: "30 hashtags", good: "3-5 relevant only", icon: "🏷️" },
                  { bad: "No CTA", good: "Save/share/comment bolo", icon: "👉" },
                  { bad: "Wall of text", good: "Short paras, line breaks", icon: "📏" },
                ].map((item) => (
                  <div key={item.bad} className="p-3.5 rounded-2xl border border-red-200 bg-red-50/50">
                    <div className="flex items-start gap-2.5">
                      <span className="text-[18px]">{item.icon}</span>
                      <div className="min-w-0">
                        <div className="flex items-center gap-1.5 mb-1">
                          <span className="text-[12px] font-medium text-red-700 line-through">{item.bad}</span>
                          <span className="text-zinc-400">→</span>
                          <span className="text-[12px] font-medium text-emerald-700">{item.good}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </section>

            {/* AI Tool */}
            <section id="ai-tool" className="scroll-mt-24 mt-14">
              <div className="relative overflow-hidden rounded-[28px] border border-zinc-200 bg-gradient-to-br from-violet-50 to-fuchsia-50">
                <div className="absolute inset-0 opacity-[0.03]" style={{ backgroundImage: `url("data:image/svg+xml,%3Csvg width='40' height='40' viewBox='0 0 40 40' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='%23000' fill-opacity='1'%3E%3Cpath d='M0 0h20v20H0z'/%3E%3C/g%3E%3C/svg%3E")` }} />
                <div className="relative p-6 sm:p-8">
                  <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-zinc-900 text-white text-[10px] font-bold uppercase tracking-wider mb-3">
                    ⚡ 2-Second Magic
                  </div>
                  
                  <h2 className="display text-[28px] sm:text-[34px] font-extrabold leading-[1.1] tracking-tight mb-3">
                    How to Generate Viral Captions in 2 Seconds
                  </h2>
                  
                  <p className="text-[15px] leading-relaxed text-zinc-700 mb-5 max-w-[600px]">
                    Sach bataun? Main ye captions khud nahi likhta. <strong>CaptionStudio AI</strong> mera secret weapon hai. 
                    Topic dalo, ye viral Hinglish caption de deta hai — hook + CTA ke saath. Free hai.
                  </p>

                  <div className="grid sm:grid-cols-3 gap-2.5 mb-6">
                    {["No 'kya likhu' tension", "100% Hinglish, natural", "Auto hook + CTA"].map((b) => (
                      <div key={b} className="flex items-center gap-1.5 text-[13px]">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" className="text-emerald-600 shrink-0"><path d="M20 6L9 17l-5-5"/></svg>
                        <span className="text-zinc-700">{b}</span>
                      </div>
                    ))}
                  </div>

                  <div className="flex flex-wrap items-center gap-3">
                    <a href="../tools/caption-generator.html" className="group inline-flex items-center gap-2 px-5 h-11 rounded-xl bg-zinc-900 text-white font-semibold text-[14px] hover:bg-black transition shadow-sm">
                      Generate your caption now
                      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" className="group-hover:translate-x-0.5 transition-transform"><path d="M5 12h14M13 5l7 7-7 7"/></svg>
                    </a>
                    <div className="flex items-center gap-2 text-[12px] text-zinc-600">
                      <div className="flex -space-x-1.5">
                        {[1,2,3].map(i => (
                          <img key={i} src={`https://images.unsplash.com/photo-${i===1?'1535713875002-d1d0cf377fde':i===2?'1494790108377-be9c29b29330':'1507003211169-0a1dd7228f2d'}?w=32&h=32&fit=crop&crop=face`} alt="" width="20" height="20" loading="lazy" className="h-5 w-5 rounded-full border-2 border-white object-cover" />
                        ))}
                      </div>
                      <span>2,847 creators today</span>
                    </div>
                  </div>
                </div>
              </div>
            </section>

            {/* Caption Studio Plans - Mobile Only */}
            <section className="xl:hidden mt-12">
              <div className="overflow-hidden rounded-3xl border border-zinc-200 bg-white shadow-sm">
                <div className="bg-gradient-to-br from-zinc-950 to-zinc-800 text-white p-6 text-center relative overflow-hidden">
                  <div className="absolute inset-0 opacity-10" style={{ backgroundImage: `url("data:image/svg+xml,%3Csvg width='24' height='24' viewBox='0 0 24 24' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='%23fff' fill-opacity='1'%3E%3Cpath d='M0 0h12v12H0z'/%3E%3C/g%3E%3C/svg%3E")` }} />
                  <div className="relative">
                    <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/10 backdrop-blur text-[11px] font-semibold mb-3">
                      Ansh Yadav Presents
                    </div>
                    <h3 className="font-bold text-[24px] leading-tight">Caption Studio.</h3>
                    <p className="text-[12px] text-zinc-400 mt-1">GORAKHPUR UP 53</p>
                  </div>
                </div>
                
                <div className="p-5">
                  <div className="text-center mb-5">
                    <div className="text-[13px] text-zinc-500 mb-1">Scale Your Business</div>
                    <div className="text-[28px] font-extrabold text-zinc-900">Starting at <span className="text-amber-500">₹999</span></div>
                    <p className="text-[13px] text-zinc-600 mt-1">Premium web development for startups</p>
                  </div>

                  <div className="grid gap-3">
                    {/* Starter */}
                    <div className="p-4 rounded-2xl border border-zinc-200">
                      <div className="flex items-center justify-between mb-3">
                        <div>
                          <h4 className="font-bold text-[16px]">Starter</h4>
                          <p className="text-[12px] text-zinc-500">Perfect to start</p>
                        </div>
                        <div className="text-right">
                          <div className="text-[24px] font-extrabold text-zinc-900">₹999</div>
                          <div className="text-[11px] text-zinc-500 -mt-1">/Lite</div>
                        </div>
                      </div>
                      <ul className="grid grid-cols-2 gap-x-3 gap-y-1.5 mb-3">
                        {["Single Landing Page", "Mobile Responsive", "Basic SEO", "WhatsApp Integration"].map((f) => (
                          <li key={f} className="flex items-center gap-1.5 text-[12px] text-zinc-700">
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" className="text-emerald-600 shrink-0"><path d="M20 6L9 17l-5-5"/></svg>
                            {f}
                          </li>
                        ))}
                      </ul>
                      <a href="https://wa.me/917985203606?text=Hi%20Ansh,%20I%20want%20Starter%20plan%20for%20%E2%82%B9999" target="_blank" rel="noopener noreferrer" className="block w-full text-center py-2.5 rounded-xl bg-zinc-900 text-white text-[14px] font-semibold hover:bg-black transition">
                        Get Started on WhatsApp
                      </a>
                    </div>

                    {/* Business - Featured */}
                    <div className="p-4 rounded-2xl border-2 border-blue-600 bg-blue-50/50 relative">
                      <div className="absolute -top-2.5 left-1/2 -translate-x-1/2 px-3 py-1 rounded-full bg-blue-600 text-white text-[10px] font-bold uppercase tracking-wider shadow">
                        Most Popular
                      </div>
                      <div className="flex items-center justify-between mb-3 mt-2">
                        <div>
                          <h4 className="font-bold text-[16px]">Business</h4>
                          <p className="text-[12px] text-zinc-600">Best for growth</p>
                        </div>
                        <div className="text-right">
                          <div className="text-[24px] font-extrabold text-blue-600">₹1,999</div>
                          <div className="text-[11px] text-zinc-500 -mt-1">/Pro</div>
                        </div>
                      </div>
                      <ul className="grid grid-cols-2 gap-x-3 gap-y-1.5 mb-3">
                        {["5 Professional Pages", "Premium UI Design", "Contact Forms", "Fast Hosting"].map((f) => (
                          <li key={f} className="flex items-center gap-1.5 text-[12px] text-zinc-700">
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" className="text-blue-600 shrink-0"><path d="M20 6L9 17l-5-5"/></svg>
                            {f}
                          </li>
                        ))}
                      </ul>
                      <a href="https://wa.me/917985203606?text=Hi%20Ansh,%20I%20want%20Business%20plan%20for%20%E2%82%B91999" target="_blank" rel="noopener noreferrer" className="block w-full text-center py-2.5 rounded-xl bg-blue-600 text-white text-[14px] font-semibold hover:bg-blue-700 transition shadow-sm">
                        Start Project on WhatsApp
                      </a>
                    </div>

                    {/* Agency */}
                    <div className="p-4 rounded-2xl border border-zinc-200">
                      <div className="flex items-center justify-between mb-3">
                        <div>
                          <h4 className="font-bold text-[16px]">Agency</h4>
                          <p className="text-[12px] text-zinc-500">Full power</p>
                        </div>
                        <div className="text-right">
                          <div className="text-[24px] font-extrabold text-zinc-900">₹4,999</div>
                          <div className="text-[11px] text-zinc-500 -mt-1">/Max</div>
                        </div>
                      </div>
                      <ul className="grid grid-cols-2 gap-x-3 gap-y-1.5 mb-3">
                        {["E-commerce/Blog", "Admin Panel", "Lifetime Updates", "Priority Support"].map((f) => (
                          <li key={f} className="flex items-center gap-1.5 text-[12px] text-zinc-700">
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" className="text-emerald-600 shrink-0"><path d="M20 6L9 17l-5-5"/></svg>
                            {f}
                          </li>
                        ))}
                      </ul>
                      <a href="https://wa.me/917985203606?text=Hi%20Ansh,%20I%20want%20Agency%20plan%20for%20%E2%82%B94999" target="_blank" rel="noopener noreferrer" className="block w-full text-center py-2.5 rounded-xl bg-zinc-900 text-white text-[14px] font-semibold hover:bg-black transition">
                        Go Enterprise on WhatsApp
                      </a>
                    </div>
                  </div>

                  <div className="mt-4 pt-4 border-t border-zinc-100 text-center">
                    <p className="text-[11px] text-zinc-500">© 2026 Caption Studio by <b>Ansh Yadav</b> • Built for speed and conversion</p>
                  </div>
                </div>
              </div>
            </section>

            {/* Related */}
            <section className="mt-12">
              <h3 className="font-bold text-[18px] mb-3">Related Resources</h3>
              <div className="grid sm:grid-cols-3 gap-3">
                {[
                  { title: "AI Caption Generator", desc: "Free tool, unlimited", href: "../tools/caption-generator.html", img: "https://images.unsplash.com/photo-1677442136019-21780ecad995?w=400&h=300&fit=crop" },
                  { title: "Earn Money Guide", desc: "Monetize Instagram", href: "../earning.html", img: "https://images.unsplash.com/photo-1579621970563-ebec7560ff3e?w=400&h=300&fit=crop" },
                  { title: "More Captions", desc: "500+ ideas library", href: "../blog/", img: "https://images.unsplash.com/photo-1611162616305-c69af2b1d197?w=400&h=300&fit=crop" },
                ].map((r) => (
                  <a key={r.title} href={r.href} className="group block overflow-hidden rounded-2xl border border-zinc-200 hover:border-zinc-300 hover:shadow-md transition-all bg-white">
                    <div className="aspect-[4/3] overflow-hidden bg-zinc-100">
                      <img src={r.img} alt={r.title} width="400" height="300" loading="lazy" className="h-full w-full object-cover group-hover:scale-105 transition-transform duration-500" />
                    </div>
                    <div className="p-3">
                      <div className="font-semibold text-[14px] group-hover:text-violet-600 transition-colors">{r.title}</div>
                      <div className="text-[12px] text-zinc-500">{r.desc}</div>
                    </div>
                  </a>
                ))}
              </div>
            </section>

            {/* FAQ */}
            <section className="mt-14">
              <h2 className="display text-[26px] font-extrabold mb-4">FAQ</h2>
              <div className="space-y-2.5">
                {[
                  { q: "How to write viral captions?", a: "Hook (first 5 words) + Value (middle) + CTA (end). Keywords daalo jo log search karte hain. Apni audience se baat karo." },
                  { q: "Is Instagram SEO important?", a: "2026 me Instagram Google se bada search engine hai creators ke liye. Caption me keywords nahi = search me nahi aaoge." },
                  { q: "How many hashtags?", a: "3-5 max, relevant. #viral #trending mat daalo. Niche specific: #hinglishcaptions #indiancreator. Quality > quantity." },
                ].map((f) => (
                  <details key={f.q} className="group p-4 rounded-2xl border border-zinc-200 bg-white open:bg-zinc-50">
                    <summary className="cursor-pointer list-none flex justify-between gap-3 font-medium text-[14px]">
                      {f.q}
                      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="shrink-0 text-zinc-400 group-open:rotate-180 transition"><path d="M6 9l6 6 6-6"/></svg>
                    </summary>
                    <p className="mt-2.5 text-[13px] leading-relaxed text-zinc-600">{f.a}</p>
                  </details>
                ))}
              </div>
            </section>
          </article>

          {/* Sidebar */}
          <aside className="hidden xl:block">
            <div className="sticky top-[88px] space-y-4">
              {/* TOC */}
              <div className="p-4 rounded-2xl border border-zinc-200 bg-zinc-50/50">
                <div className="text-[12px] font-semibold text-zinc-500 uppercase tracking-wider mb-2.5">On this page</div>
                <nav className="space-y-1">
                  {tableOfContents.map((item) => (
                    <a key={item.id} href={`#${item.id}`} className="block py-1 text-[13px] text-zinc-600 hover:text-zinc-900 truncate">
                      {item.title}
                    </a>
                  ))}
                </nav>
              </div>

              {/* Tool CTA */}
              <div className="p-5 rounded-2xl border border-zinc-900 bg-zinc-900 text-white">
                <div className="text-[11px] font-bold uppercase tracking-wider text-zinc-400 mb-2">Free Tool</div>
                <h3 className="font-bold text-[17px] leading-tight mb-2">Generate captions in 2 sec</h3>
                <p className="text-[13px] text-zinc-300 mb-4 leading-snug">Stop wasting time. AI writes viral Hinglish captions.</p>
                <a href="../tools/caption-generator.html" className="block w-full text-center py-2.5 rounded-xl bg-white text-zinc-900 font-semibold text-[13px] hover:bg-zinc-100 transition">
                  Try Free →
                </a>
              </div>

              {/* Caption Studio Plans Poster */}
              <div className="overflow-hidden rounded-2xl border border-zinc-200 bg-white shadow-sm">
                <div className="bg-gradient-to-br from-zinc-950 to-zinc-800 text-white p-4 text-center relative overflow-hidden">
                  <div className="absolute inset-0 opacity-10" style={{ backgroundImage: `url("data:image/svg+xml,%3Csvg width='20' height='20' viewBox='0 0 20 20' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='%23fff' fill-opacity='1'%3E%3Cpath d='M0 0h10v10H0z'/%3E%3C/g%3E%3C/svg%3E")` }} />
                  <div className="relative">
                    <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-white/10 backdrop-blur text-[10px] font-semibold mb-2">
                      Ansh Yadav Presents
                    </div>
                    <h3 className="font-bold text-[18px] leading-tight">Caption Studio.</h3>
                    <p className="text-[11px] text-zinc-400 mt-0.5">GORAKHPUR UP 53</p>
                  </div>
                </div>
                
                <div className="p-4">
                  <div className="text-center mb-4">
                    <div className="text-[12px] text-zinc-500 mb-1">Scale Your Business</div>
                    <div className="text-[22px] font-extrabold text-zinc-900">Starting at <span className="text-amber-500">₹999</span></div>
                  </div>

                  <div className="space-y-2.5">
                    {/* Starter */}
                    <div className="p-3 rounded-xl border border-zinc-200 hover:border-zinc-300 transition">
                      <div className="flex items-center justify-between mb-1.5">
                        <span className="text-[13px] font-semibold">Starter</span>
                        <span className="text-[16px] font-bold text-zinc-900">₹999</span>
                      </div>
                      <ul className="space-y-1 mb-2.5">
                        {["Landing Page", "Mobile Responsive", "Basic SEO", "WhatsApp"].map((f) => (
                          <li key={f} className="flex items-center gap-1.5 text-[11px] text-zinc-600">
                            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" className="text-emerald-600"><path d="M20 6L9 17l-5-5"/></svg>
                            {f}
                          </li>
                        ))}
                      </ul>
                      <a href="https://wa.me/917985203606?text=Hi%20Ansh,%20I%20want%20Starter%20plan%20for%20%E2%82%B9999" target="_blank" rel="noopener noreferrer" className="block w-full text-center py-1.5 rounded-lg bg-zinc-900 text-white text-[12px] font-medium hover:bg-black transition">
                        Get Started
                      </a>
                    </div>

                    {/* Business - Featured */}
                    <div className="p-3 rounded-xl border-2 border-blue-600 bg-blue-50/50 relative">
                      <div className="absolute -top-2 left-1/2 -translate-x-1/2 px-2 py-0.5 rounded-full bg-blue-600 text-white text-[9px] font-bold uppercase tracking-wider">
                        Popular
                      </div>
                      <div className="flex items-center justify-between mb-1.5 mt-1">
                        <span className="text-[13px] font-semibold">Business</span>
                        <span className="text-[16px] font-bold text-blue-600">₹1,999</span>
                      </div>
                      <ul className="space-y-1 mb-2.5">
                        {["5 Pages", "Premium UI", "Forms & Maps", "Fast Hosting"].map((f) => (
                          <li key={f} className="flex items-center gap-1.5 text-[11px] text-zinc-700">
                            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" className="text-blue-600"><path d="M20 6L9 17l-5-5"/></svg>
                            {f}
                          </li>
                        ))}
                      </ul>
                      <a href="https://wa.me/917985203606?text=Hi%20Ansh,%20I%20want%20Business%20plan%20for%20%E2%82%B91999" target="_blank" rel="noopener noreferrer" className="block w-full text-center py-1.5 rounded-lg bg-blue-600 text-white text-[12px] font-medium hover:bg-blue-700 transition">
                        Start Project
                      </a>
                    </div>

                    {/* Agency */}
                    <div className="p-3 rounded-xl border border-zinc-200 hover:border-zinc-300 transition">
                      <div className="flex items-center justify-between mb-1.5">
                        <span className="text-[13px] font-semibold">Agency</span>
                        <span className="text-[16px] font-bold text-zinc-900">₹4,999</span>
                      </div>
                      <ul className="space-y-1 mb-2.5">
                        {["E-commerce/Blog", "Admin Panel", "Free Updates", "Priority"].map((f) => (
                          <li key={f} className="flex items-center gap-1.5 text-[11px] text-zinc-600">
                            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" className="text-emerald-600"><path d="M20 6L9 17l-5-5"/></svg>
                            {f}
                          </li>
                        ))}
                      </ul>
                      <a href="https://wa.me/917985203606?text=Hi%20Ansh,%20I%20want%20Agency%20plan%20for%20%E2%82%B94999" target="_blank" rel="noopener noreferrer" className="block w-full text-center py-1.5 rounded-lg bg-zinc-900 text-white text-[12px] font-medium hover:bg-black transition">
                        Go Enterprise
                      </a>
                    </div>
                  </div>

                  <div className="mt-3 pt-3 border-t border-zinc-100 text-center">
                    <p className="text-[10px] text-zinc-500">Built for speed and conversion</p>
                  </div>
                </div>
              </div>

              {/* Telegram */}
              <div className="p-5 rounded-2xl border border-[#229ED9]/20 bg-[#229ED9]/5">
                <div className="flex items-center gap-2.5 mb-3">
                  <div className="h-9 w-9 rounded-xl bg-[#229ED9] grid place-items-center shadow-sm">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="white"><path d="M12 0C5.373 0 0 5.373 0 12s5.373 12 12 12 12-5.373 12-12S18.627 0 12 0zm5.894 8.221l-1.97 9.28c-.145.658-.537.818-1.084.508l-3-2.21-1.446 1.394c-.14.18-.357.295-.6.295l.213-3.054 5.56-5.022c.24-.213-.054-.334-.373-.121l-6.87 4.326-2.96-.924c-.64-.203-.658-.64.135-.954l11.57-4.458c.538-.196 1.006.128.832.941z"/></svg>
                  </div>
                  <div>
                    <div className="font-bold text-[14px]">Join Telegram</div>
                    <div className="text-[11px] text-zinc-600">12,000+ creators</div>
                  </div>
                </div>
                <p className="text-[12px] text-zinc-600 mb-3 leading-relaxed">Daily captions, growth hacks, monetization.</p>
                <a href="https://t.me/skill2incomehub" target="_blank" rel="noopener noreferrer" className="block w-full text-center py-2.5 rounded-xl bg-[#229ED9] text-white font-semibold text-[13px] hover:bg-[#1e8bc3] transition">
                  Join Free →
                </a>
              </div>

              {/* Image Card */}
              <div className="overflow-hidden rounded-2xl border border-zinc-200">
                <img 
                  src="https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=400&h=300&fit=crop" 
                  alt="Instagram analytics showing growth from viral captions"
                  width="400"
                  height="300"
                  loading="lazy"
                  className="w-full aspect-[4/3] object-cover"
                />
                <div className="p-3 bg-white">
                  <div className="text-[12px] font-medium">Real results from our users</div>
                  <div className="text-[11px] text-zinc-500">Avg +340% reach in 30 days</div>
                </div>
              </div>
            </div>
          </aside>
        </div>

        {/* Bottom CTA */}
        <div className="mt-16 p-8 sm:p-10 rounded-[28px] border border-zinc-200 bg-zinc-50 text-center">
          <h3 className="display text-[26px] sm:text-[32px] font-extrabold mb-2">Ready to go viral?</h3>
          <p className="text-[15px] text-zinc-600 mb-6 max-w-[520px] mx-auto">
            100+ captions mil gaye. Ab AI se unlimited generate karo. Blog → Tool → Earning → Telegram.
          </p>
          <div className="flex flex-wrap justify-center gap-2.5">
            <a href="../tools/caption-generator.html" className="px-5 h-11 inline-flex items-center gap-1.5 rounded-xl bg-zinc-900 text-white font-semibold text-[14px] hover:bg-black transition">
              Generate Now
            </a>
            <a href="https://t.me/skill2incomehub" target="_blank" rel="noopener noreferrer" className="px-5 h-11 inline-flex items-center gap-1.5 rounded-xl bg-[#229ED9] text-white font-semibold text-[14px] hover:bg-[#1e8bc3] transition">
              Join Telegram
            </a>
            <a href="../earning.html" className="px-5 h-11 inline-flex items-center gap-1.5 rounded-xl border border-zinc-300 font-medium text-[14px] hover:bg-white transition">
              Earn Money Guide
            </a>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-zinc-200 mt-16 bg-zinc-50">
        <div className="mx-auto max-w-[1180px] px-4 py-8">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 text-[13px] text-zinc-600">
            <div className="flex items-center gap-2">
              <div className="h-6 w-6 rounded-lg bg-zinc-900 grid place-items-center">
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" className="text-white">
                  <path d="M4 8V6a2 2 0 0 1 2-2h2M4 16v2a2 2 0 0 0 2 2h2M16 4h2a2 2 0 0 1 2 2v2M16 20h2a2 2 0 0 0 2-2v-2" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
                </svg>
              </div>
              <span>© 2026 CaptionStudio.in — Made for Indian creators</span>
            </div>
            <div className="flex items-center gap-4">
              <a href="../tools/caption-generator.html" className="hover:text-zinc-900">AI Tool</a>
              <a href="../guide.html" className="hover:text-zinc-900">Guide</a>
              <a href="../earning.html" className="hover:text-zinc-900">Earn</a>
              <a href="../blog/" className="hover:text-zinc-900">Blog</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}